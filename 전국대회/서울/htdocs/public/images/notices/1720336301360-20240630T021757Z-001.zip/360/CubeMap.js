class CubeMap {
    constructor(options) {
        this.container = options.container;
        // this.cubeWidth = options.width;
        // this.cubeHeight = options.height;
        // this.source = options.source;
        this.cubeImages = [];
        this.faces = ['front', 'back', 'top', 'left', 'right', 'bottom'];
    }

    async init(source) {
        await this.createCubeImages(source);
        this.drawCanvas();
    }

    async createCubeImages(source) {
        this.baseImage = await loadImage(source);
        this.cubeWidth = this.baseImage.width / 4;
        this.cubeHeight = this.baseImage.height / 3;

        const offscreenCanvas = new OffscreenCanvas(this.baseImage.width, this.baseImage.height);
        const ctx = offscreenCanvas.getContext('2d');

        ctx.drawImage(this.baseImage, 0, 0);

        // const positions = {
        //     front: {x: this.cubeWidth, y: this.cubeHeight},
        //     back: {x: this.cubeWidth * 3, y: this.cubeHeight},
        //     top: {x: this.cubeWidth, y: 0},
        //     bottom: {x: this.cubeWidth, y: this.cubeHeight * 2},
        //     left: {x: 0, y: this.cubeHeight},
        //     right: {x: this.cubeWidth * 2, y: this.cubeHeight}
        // };
        const positions = this.initPositions();
        console.log(positions)
        const promises = this.faces.map((face) => this.createCubeFace(ctx, positions[face], face));
    
        this.cubeImages = await Promise.all(promises);
    }

    async createCubeFace(ctx, pos, face) {
        const imageData = ctx.getImageData(pos.x, pos.y, this.cubeWidth, this.cubeHeight);
        const faceCanvas = new OffscreenCanvas(this.cubeWidth, this.cubeHeight);
        const faceCtx = faceCanvas.getContext('2d')

        faceCtx.putImageData(imageData, 0, 0);

        const blob = await faceCanvas.convertToBlob();
        const img = new Image();
        
        return new Promise((resolve) => {
            img.onload = () => resolve(img);
            img.src = URL.createObjectURL(blob);
            img.alt = face; // 디버깅 목적으로 뒀다.
        });
    }

    initPositions() {
        const coords = {
            front: [1, 1],
            back: [3, 1],
            top: [1, 0],
            left: [0, 1],
            right: [2, 1],
            bottom: [1, 2]
        }

        return this.faces.reduce((acc, cur) => {
            const coord = coords[cur];
            acc[cur] = {
                x: this.cubeWidth * coord[0],
                y: this.cubeHeight * coord[1]
            }
            return acc;
        }, {})
    }

    drawCanvas() {
        const { cubeImages, faces, cubeWidth, cubeHeight } = this;

        for (let i = 0; i < cubeImages.length; i++) {
            const faceCanvas = document.querySelector(`.canvas-${faces[i]}`);

            const faceContext = faceCanvas.getContext('2d');
            faceCanvas.style.width = `${cubeWidth + 4}px`;
            faceCanvas.style.height = `${cubeHeight + 4}px`;
            faceCanvas.width = cubeWidth + 4;
            faceCanvas.height = cubeHeight + 4;
            faceContext.drawImage(cubeImages[i], 2, 2);
        }
    }


    getFaceTransforms() {
        const s = this.cubeWidth / 2;
        const transforms = {
            // 정면
            front: `translate3d(-${s + 2}px, -${s + 2}px, -${s}px)`,
            // X축과 Z축을 기준으로 각각 180도 회전 / 뒷면을 뒤집어 뒤쪽으로 배치
            back: `translate3d(${s + 2}px, -${s + 2}px, ${s}px) rotateX(180deg) rotateZ(180deg)`,
            // X축을 기준으로 270도 회전하여 윗면을 위쪽으로 배치
            top: `translate3d(-${s + 2}px, -${s}px, ${s + 2}px) rotateX(270deg)`,
            // X축을 기준으로 90도 회전하여 아랫면을 아래쪽으로 배치
            bottom: `translate3d(-${s + 2}px, ${s}px, -${s + 2}px) rotateX(90deg)`,
            // X축을 기준으로 180도 회전하여 뒤집고, Y축을 기준으로 90도 회전하여 왼쪽으로 배치하며, Z축을 기준으로 180도 회전
            left: `translate3d(-${s}px, -${s + 2}px, ${s + 2}px) rotateX(180deg) rotateY(90deg) rotateZ(180deg)`,
            // Y축을 기준으로 270도 회전하여 오른쪽으로 배치
            right: `translate3d(${s}px, -${s + 2}px, -${s + 2}px) rotateY(270deg)`
        };

        return transforms;
    }

    /**
     * Pitch - 객체의 수직 축을 중심으로 한 위아래 방향의 기울기 / 카메라나 물체가 위나 아래를 바라보는 각도
     * 
     * Yaw - 객체의 수직 축을 중심으로 좌우 방향의 회전 / 카메라나 물체가 좌측 또는 우측을 바라보는 각도
     * 
     * HFOV (Horizontal Field of View) - 수평 시야각을 나타내며, 카메라가 한 번에 볼 수 있는 각도 / 카메라의 시야가 얼마나 넓은지 나타냄
     */
    render(pitch, yaw, hfov) {
        const faceTransforms = this.getFaceTransforms();

        // focal은 주어진 수평 시야각(hfov)을 기반으로 한 초점 거리
        const focal = 1 / Math.tan(hfov / 2);

        // zoom은 초점 거리와 컨테이너 너비를 곱한 값
        const zoom = `${focal * this.container.clientWidth}px`;

        /**
         * perspective(${zoom}): 원근감 설정 / zoom 값이 클 수록 더 작아보임
         * translateZ(${zoom}): 
         * rotateX(${pitch}rad): X 축 회전 / 양수면 큐브가 위쪽으로 회전하고, 음수면 아래쪽으로 회전
         * rotateY(${yaw}rad): Y 축 회전 / 양수면 큐브가 오른쪽으로 회전하고, 음수면 왼쪽으로 회전
         */
        const transform = `perspective(${zoom}) translateZ(${zoom}) rotateX(${pitch}rad) rotateY(${yaw}rad)`;

        for (let i = 0; i < this.faces.length; i++) {
            const face = this.faces[i];
            const faceCanvas = document.querySelector(`.canvas-${face}`);
            faceCanvas.style.transform = transform + faceTransforms[face];
        }
    }
}