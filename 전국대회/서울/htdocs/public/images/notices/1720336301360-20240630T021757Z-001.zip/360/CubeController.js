/**
 * 탄젠트: 그 각의 대변(마주보는 변)의 길이를 인접변(바로 옆의 변)의 길이로 나눈 값
 * 아크 탄젠트: 주어진 탄젠트 값에 해당하는 각도
 * https://ko.khanacademy.org/math/geometry/hs-geo-trig/hs-geo-solve-for-an-angle/a/inverse-trig-functions-intro
 */
class CubeController {
    constructor(options) {
        this.container = options.container;
        this.source = options.source;
        this.config = {
            // Horizontal Angle of View (수평 시야각)
            // haov: 360,
            // ertical Angle of View (수직 시야각)
            // vaov: 180,
            // 카메라의 수평 회전 각도
            yaw: 0,
            // 카메라가 수평으로 회전할 수 있는 최소 각도
            minYaw: -180,
            // 카메라가 수평으로 회전할 수 있는 최대 각도
            maxYaw: 180,
            // Horizontal Field of View (수평 시야 범위)
            // 카메라가 한 번에 볼 수 있는 수평 범위의 크기
            hfov: 100,
            
            minHfov: 50,
            maxHfov: 120,
            // 카메라가 수직으로 회전할 수 있는 최소 각도
            minPitch: -90,
            // 카메라가 수직으로 회전할 수 있는 최대 각도
            maxPitch: 90,
            // 카메라의 수직 회전 각도
            pitch: 0,
            
            animating: false,
            isMove: false,
            downPointer: {
                x: 0,
                y: 0,
                yaw: 0,
                pitch: 0
            }
        }
    }

    async init() {
        this.cubeMap = new CubeMap({
            container: this.container
        });

        await this.cubeMap.init(this.source);
        this.animateInit();

        this.container.addEventListener('mousedown', this.onDocumentMouseDown);
        document.addEventListener('mousemove', this.onDocumentMouseMove);
        document.addEventListener('mouseup', this.onDocumentMouseUp);
        this.container.addEventListener('mousewheel', this.onDocumentMouseWheel)
    }

    getMousePosition(event) {
        const bounds = this.container.getBoundingClientRect();
        const pos = {
            x: (event.clientX || event.pageX) - bounds.left,
            y: (event.clientY || event.pageY) - bounds.top
        };

        return pos;
    }

    onDocumentMouseDown = (event) => {
        const { x, y } = this.getMousePosition(event);
        const { yaw, pitch } = this.config;

        this.config.isMove = true;
        this.config.downPointer = {
            x, 
            y,
            yaw,
            pitch
        };
    
        this.animateInit();
    }

    onDocumentMouseMove = (event) => {
        if (!this.config.isMove) return;
        
        const { clientWidth, clientHeight } = this.container;
        const { downPointer, hfov } = this.config;

        // 마우스 포지션을 가지고 온다.
        const pos = this.getMousePosition(event);

        /**
         * yaw 계산 공식
         * Math.atan(downPointer.x / clientWidth * 2 - 1): 
         *  - 마우스를 클릭했을 때의 X 좌표를 기준으로 아크탄젠트 값 계산
         *  - 화면의 좌우 이동을 각도로 변환
         * 
         * Math.atan(pos.x / clientWidth * 2 - 1)
         *  - 현재 마우스 X 좌표를 기준으로 아크탄젠트 값
         * 
         * 두 아크탄젠트 값의 차이를 계산하여 마우스의 이동 거리를 각도로 변환
         * 
         * * 180 / Math.PI 
         *  - 라디안을 degree 단위로 변환
         * 
         * * hfov / 90
         *  - 수평 시야 범위를 고려하여 각도를 조정
         * 
         * + downPointer.yaw 
         *  - 기본 yaw 값 더해서 최종 yaw 값 구하기
         */
        const yaw = ((Math.atan(downPointer.x / clientWidth * 2 - 1) - Math.atan(pos.x / clientWidth * 2 - 1)) * 180 / Math.PI * hfov / 90) + downPointer.yaw;
        
        /**
         * 수직 시야각 계산 (Vertical Field of View)
         * 
         * hfov / 360 * Math.PI
         *  - 수평 시야 범위를 라디안 단위로 변환
         * 
         * Math.tan()
         *  - 수평 시야 범위의 탄젠트 값을 계산
         * 
         * * clientHeight / clientWidth
         *  - 뷰포트의 종횡비를 고려하여 수직 시야 범위를 조정
         * 
         * 2 * Math.atan()
         *  - 조정된 값의 아크탄젠트 값을 계산하고, 2배 / 수직 시야 범위를 라디안 단위 변환
         * 
         * * 180 / Math.PI
         *  - 최종적으로 라디안을 도 단위로 변환
         */
        const vfov = 2 * Math.atan(Math.tan(hfov / 360 * Math.PI) * clientHeight / clientWidth) * 180 / Math.PI;
        
        /**
         * pitch 계산
         * 
         * Math.atan(pos.y / clientHeight * 2 - 1)
         *  - 현재 마우스 Y 좌표를 기준으로 아크탄젠트 값을 계산
         *  - 화면의 상하 이동을 각도로 변환
         * 
         * Math.atan(downPointer.y / clientHeight * 2 - 1)
         *  - 마우스를 클릭했을 때의 Y 좌표를 기준으로 아크탄젠트 값을 계산
         * 
         * 두 아크탄젠트 값의 차이를 계산하여 마우스의 이동 거리를 각도로 변환
         * 
         * 단위 변환
         *  * 180 / Math.PI를 통해 라디안을 도 단위로 변환
         *  * vfov / 90를 통해 수직 시야 범위를 고려하여 각도를 조정
         * 
         * downPointer.pitch 값을 더하여 최종 Pitch 각도를 계산
         */
        const pitch = ((Math.atan(pos.y / clientHeight * 2 - 1) - Math.atan(downPointer.y / clientHeight * 2 - 1)) * 180 / Math.PI * vfov / 90) + downPointer.pitch;
    
        this.config.yaw = yaw;
        this.config.pitch = pitch;
    }

    onDocumentMouseUp = () => {
        this.config.isMove = false;
    }

    onDocumentMouseWheel = (event) => {
        event.preventDefault();

        if (!event.wheelDeltaY) return;

        const { hfov, minHfov, maxHfov } = this.config;

        let newHfov = hfov - event.wheelDeltaY * 0.05;
        
        if (newHfov < minHfov) {
            newHfov = minHfov;
        }

        if (newHfov > maxHfov) {
            newHfov = maxHfov;
        }

        this.config.hfov = newHfov;
        console.log(newHfov)

        this.animateInit();
    }

    render() {
        const config = this.config;

        // 카메라가 회전할 수 있는 수평 각도의 범위
        const yawRange = config.maxYaw - config.minYaw;

        let minYaw = -180;
        let maxYaw = 180;

        // yaw 범위 조정
        if (yawRange < 360) {
            minYaw = config.minYaw + config.hfov / 2;
            maxYaw = config.maxYaw - config.hfov / 2;
            
            if (yawRange < config.hfov) {
                minYaw = maxYaw = (minYaw + maxYaw) / 2;
            }
    
            config.yaw = Math.max(minYaw, Math.min(maxYaw, config.yaw));
        }
        
        // yaw 정규화 (360 사이로)
        if (config.yaw > 360) {
            config.yaw -= 360;
        } else if (config.yaw < -360) {
            config.yaw += 360;
        }

        // 위와 동일
        const vfov = 2 * Math.atan(Math.tan(config.hfov / 180 * Math.PI * 0.5) / (this.container.clientWidth / this.container.clientHeight)) / Math.PI * 180;

        // pitch 범위 조정
        let minPitch = config.minPitch + vfov / 2;
        let maxPitch = config.maxPitch - vfov / 2;

        const pitchRange = config.maxPitch - config.minPitch;

        if (pitchRange < vfov) {
            minPitch = maxPitch = (minPitch + maxPitch) / 2;
        }

        config.pitch = Math.max(minPitch, Math.min(maxPitch, config.pitch));

        // 라디안 변환
        this.cubeMap.render(config.pitch * Math.PI / 180, config.yaw * Math.PI / 180, config.hfov * Math.PI / 180)
    }

    /**
     * animating이 아닐 때에 한해서만 동작하도록 한다.
     */
    animateInit() {
        if (this.config.animating) {
            return;
        }

        this.config.animating = true;
        this.animate();
    }

    /**
     * Arrow Function: 중요
     */
    animate = () => {
        this.render();

        if (this.config.isMove) {
            requestAnimationFrame(this.animate);
        } else {
            this.config.animating = false;
        }
    }
}