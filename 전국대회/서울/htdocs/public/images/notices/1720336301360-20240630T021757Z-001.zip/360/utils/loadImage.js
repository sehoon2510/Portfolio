const loadImage = (source) => {
    return new Promise((res, rej) => {
        const img = new Image();
        img.src = source;
        img.onload = () => res(img);
        img.onerror = (err) => rej(err);
    })
}